sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/core/routing/History"
	], function (Controller, History) {
	"use strict";

	return Controller.extend("com.sap.training.ux402.masterdetailUX402_MasterDetailExercise.Component", {

		init: function() {
			//this.oListSelector = new ListSelector();
		},
		getRouter: function() {
			return this.getOwnerComponent().getRouter();
		},
		getListSelector: function() {
			return this.getOwnerComponent().oListSelector;
		},
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		onNavBack: function() {
			var sPreviousHash = sap.ui.core.routingHistory.getInstance().getPreviousHash();
			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				var bReplace = true;
				this.getRouter().navTo("master", {}, bReplace);
			}
		}
	});
});