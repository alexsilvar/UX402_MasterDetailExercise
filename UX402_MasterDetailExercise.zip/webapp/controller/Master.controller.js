sap.ui.define([
	"com/sap/training/ux402/masterdetailUX402_MasterDetailExercise/controller/BaseController",
	"sap/ui/Device"
], function(Controller, Device) {
	"use strict";

	return Controller.extend("com.sap.training.ux402.masterdetailUX402_MasterDetailExercise.controller.Master", {
		onInit: function() {
			var oList = this.byId("list");
			this._oList = oList;
			var oSelector = this.getListSelector();
			oSelector.setBoundMasterList(oList);
			this.getRouter().getRoute("master").attachPatternMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);
		},
		_onMasterMatched: function() {
			this.getListSelector().oWhenListLoadingIsDone.then(
				function(mParams) {
					if (mParams.list.getMode() === "None") {
						return;
					}
					var sObjectId = mParams.firstListItem.getBindingContext().getProperty("AirLineID");
					this._navigateToCarrierDetails(sObjectId, true);
				}.bind(this)
			);
		},
		onBypassed: function() {
			this._oList.removeSelections(true);
		},
		onSelect: function(oEvent) {
			this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		},
		_showDetail: function(oItem) {
			var bReplace = !Device.system.phone;
			var sCarrierId = oItem.getBindingContext().getProperty("AirLineID");
			this._navigateToCarrierDetails(sCarrierId, bReplace);
		},
		_navigateToCarrierDetails: function(sCarrierId, bReplace) {
			this.getRouter().navTo("carrierdetails", {
				objectId: sCarrierId
			}, false);
		}

	});

});